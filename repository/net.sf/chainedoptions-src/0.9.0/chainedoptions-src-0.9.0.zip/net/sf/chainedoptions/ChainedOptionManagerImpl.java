package net.sf.chainedoptions;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.InitializingBean;

/**
 * Default implementation of <code>ChainedOptionManager</code>. Operates on an
 * ordered collection of <code>ChainedOption</code> objects.
 * 
 * @author Mattias Arthursson
 * @author Ulrik Sandberg
 * 
 */
public class ChainedOptionManagerImpl implements ChainedOptionManager,
        InitializingBean {

    private List chainedOptions;

    /**
     * Iterate through the collection of <code>ChainedOption</code> objects and
     * call <code>retrieveOptions</code> and <code>updateValue</code>. Put
     * the option Lists in the map with keys retrieved from the ChainedOption
     * objects.
     * 
     * @param model
     *            the map to store option Lists in.
     * @param command
     *            the command to operate on.
     * @param context
     *            the context.
     */
    public void referenceData(Map model, Object command, Object context) {
        for (Iterator iter = chainedOptions.iterator(); iter.hasNext();) {
            ChainedOption chainedOption = (ChainedOption) iter.next();
            List options = chainedOption.retrieveOptions(command, context);
            model.put(chainedOption.getOptionsKey(), options);
            chainedOption.updateValue(command, options, context);
        }
    }

    /**
     * @return Returns the chainedOptions.
     */
    public List getChainedOptions() {
        return chainedOptions;
    }

    /**
     * @param chainedOptions
     *            The chainedOptions to set.
     */
    public void setChainedOptions(List chainedOptions) {
        this.chainedOptions = chainedOptions;
    }

    public void afterPropertiesSet() throws Exception {
        if (chainedOptions == null) {
            throw new IllegalArgumentException(
                    "Property 'chainedOptions' must be set.");
        }
    }
}
