package net.sf.chainedoptions;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * Simple name/value pair bean for use in cases where an item has a value and a
 * display label.
 * 
 * @author Mattias Arthursson
 * @author Ulrik Sandberg
 */
public class LabelValueBean implements Comparable {
    private String value;

    private String label;

    public LabelValueBean(String label, String value) {
        this.value = value;
        this.label = label;
    }

    /**
     * @return Returns the label.
     */
    public String getLabel() {
        return label;
    }

    /**
     * @param label
     *            The label to set.
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * @return Returns the value.
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value
     *            The value to set.
     */
    public void setValue(String value) {
        this.value = value;
    }

    public int compareTo(Object o) {
        LabelValueBean that = (LabelValueBean) o;
        return this.label.compareTo(that.label);
    }

    /*
     * @see java.lang.Object#equals(java.lang.Object)
     */
    public boolean equals(Object obj) {
        if (obj == null || !obj.getClass().equals(getClass())) {
            return false;
        }
        LabelValueBean that = (LabelValueBean) obj;
        return new EqualsBuilder().append(value, that.value).append(label,
                that.label).isEquals();
    }

    /*
     * @see java.lang.Object#hashCode()
     */
    public int hashCode() {
        return new HashCodeBuilder().append(value).append(label).toHashCode();
    }
}
