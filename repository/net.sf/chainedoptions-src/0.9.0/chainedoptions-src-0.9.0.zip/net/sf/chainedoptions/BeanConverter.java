package net.sf.chainedoptions;

import java.util.List;

/**
 * Interface that provides the operations required for converting beans of some
 * kind into LabelValueBeans.
 * 
 * @see net.sf.chainedoptions.AbstractBeanConverter
 * @author Mattias Arthursson
 * @author Ulrik Sandberg
 */
public interface BeanConverter {
    /**
     * Convert a list of beans of some sort into a list of LabelValueBean
     * objects.
     * 
     * @param beans
     *            A list of beans. A bean may be any object, but typically only
     *            one class is handled by a single BeanConverter implementation.
     * @return A list of {@link LabelValueBean}objects.
     */
    List convert(List beans);
}
