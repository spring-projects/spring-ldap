package net.sf.chainedoptions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Abstract class that implements the BeanConverter interface and provides an
 * implementation of {@link #convert(List)}that loops through a list of beans
 * and calls a template method for each bean.
 * <p>
 * Subclasses must implement the template method {@link #convertBean(Object)}.
 * Below is an example of such an implementation:
 * 
 * <pre>
 * package com.acme.valuehandler;
 * 
 * import com.acme.valuehandler.model.RegionBean;
 * 
 * public class RegionBeanConverter extends AbstractBeanConverter {
 * 
 *     protected LabelValueBean convertBean(Object bean) {
 *         RegionBean regionBean = ((RegionBean) bean);
 *         return new LabelValueBean(regionBean.getName(), regionBean.getCode());
 *     }
 * }
 * </pre>
 * 
 * @author Mattias Arthursson
 * @author Ulrik Sandberg
 */
public abstract class AbstractBeanConverter implements BeanConverter {

    /**
     * Default implementation that loops through the supplied list of beans and
     * calls {@link #convertBean(Object)}on each one of them.
     * 
     * @param beans
     *            list of beans of any kind.
     * @return a new List containing the corresponding
     *         <code>LabelValueBean</code> objects.
     */
    public List convert(List beans) {
        List retval = new ArrayList(beans.size());
        for (Iterator iter = beans.iterator(); iter.hasNext();) {
            LabelValueBean bean = convertBean(iter.next());
            retval.add(bean);
        }

        return retval;
    }

    /**
     * Template method that must provide the conversion of a single object into
     * a <code>LabelValueBean</code>.
     * 
     * @param object
     *            An object to convert.
     * @return A LabelValueBean object.
     */
    protected abstract LabelValueBean convertBean(Object object);
}
