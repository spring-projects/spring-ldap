package net.sf.chainedoptions.support;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import net.sf.chainedoptions.ChainedOptionStrategy;
import net.sf.chainedoptions.LabelValueBean;

import org.springframework.beans.factory.InitializingBean;


/**
 * Strategy that adds a set of extra items to a given list of options. The set
 * of extra items is configurable. The strategy also provides a default value,
 * which is also configurable.
 * 
 * @author Mattias Arthursson
 * @author Ulrik Sandberg
 */
public class ExtraItemsStrategy implements ChainedOptionStrategy,
        InitializingBean {

    private List extraItems;

    private LabelValueBean defaultItem;

    /*
     * @see net.sf.chainedoptions.ChainedOptionStrategy#adjustAndSort(java.util.List, java.lang.Object)
     */
    public List adjustAndSort(List options, Object context) {
        List adjusted = new LinkedList(options);
        adjusted.addAll(extraItems);
        Collections.sort(adjusted);
        return adjusted;
    }

    /*
     * @see net.sf.chainedoptions.ChainedOptionStrategy#getDefaultValue(java.util.List, java.lang.Object)
     */
    public String getDefaultValue(List options, Object context) {
        return getDefaultItem().getValue();
    }

    /**
     * Extra items are items that signify special values, like ANY, EMPTY,
     * NOCHANGE etc.
     * 
     * @param extraItems
     *            The extra items to set as a list of LabelValueBean objects.
     */
    public void setExtraItems(List extraItems) {
        this.extraItems = extraItems;
    }

    /**
     * The default item is the item in the list that should be selected when the
     * list is first displayed.
     * 
     * @return Returns the default item as a LabelValueBean.
     */
    public LabelValueBean getDefaultItem() {
        return defaultItem;
    }

    /**
     * The default item is the item in the list that should be selected when the
     * list is first displayed.
     * 
     * @param defaultItem
     *            The default item to set as a LabelValueBean.
     */
    public void setDefaultItem(LabelValueBean defaultItem) {
        this.defaultItem = defaultItem;
    }

    /*
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    public void afterPropertiesSet() throws Exception {
        if (defaultItem == null) {
            throw new IllegalArgumentException(
                    "Property 'defaultItem' must be set");
        }
        if (!extraItems.contains(defaultItem)) {
            throw new IllegalArgumentException(
                    "Property 'defaultItem' does not exist in 'extraItems'");
        }
    }
}
