package net.sf.chainedoptions;

import java.util.Map;

/**
 * Responsible for retrieving options and maintaining default values in command
 * objects.
 * 
 * @author Mattias Arthursson
 * @author Ulrik Sandberg
 */
public interface ChainedOptionManager {
    /**
     * Sets option Lists in the supplied map and makes sure that the command
     * object always has valid values for all managed properties.
     * 
     * @param model
     *            Map where the option Lists will be stored.
     * @param command
     *            the command object to operate on.
     * @param context
     *            any context that might be useful for selecting valid options
     *            and default values. E.g. a Request might be passed as a
     *            context for filtering options based on user access.
     */
    void referenceData(Map model, Object command, Object context);
}
