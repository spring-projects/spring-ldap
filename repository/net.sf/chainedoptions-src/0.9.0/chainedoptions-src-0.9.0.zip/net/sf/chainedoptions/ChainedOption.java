package net.sf.chainedoptions;

import java.util.List;

/**
 * An <code>ChainedOption</code> is responsible for handling an attribute in a
 * command object, such as a Struts ActionForm or plain Java Bean, and the
 * available options for this attribute.
 * <p />
 * To fulfil this responsibility, implement the
 * {@link #retrieveOptions(Object, Object)}method, which should extract any
 * values that this <code>ChainedOption</code> depends from the command object
 * and retrieve the available options for these values. Also, implement the
 * {@link #updateValue(Object, List, Object)}method to check the current value
 * of the managed attribute against the current list of available options and
 * optionally update the value if the current one is not present in the list.
 * <p />
 * Example: The value object is a Query object of some sort. It has a
 * <code>region</code> property and a <code>country</code> property. Our
 * <code>ChainedOption</code> corresponds to the <code>country</code> property
 * in the query object. The {@link net.sf.chainedoptions.ChainedOptionManager}
 * managing this <code>ChainedOption</code> decides that a new list of available
 * countries is needed, perhaps because the <code>region</code> property has
 * changed. The <code>ChainedOptionManager</code> calls
 * {@link #retrieveOptions(Object, Object)}method on the
 * <code>ChainedOption</code>, which knows how to get the countries that match
 * the current <code>region</code> in the query object.
 * <p>
 * The <code>ChainedOptionManager</code> then calls
 * {@link #updateValue(Object, List, Object)}on the ChainedOption, which knows
 * how to set the <code>country</code> property of the query object. It takes
 * the list of available options as a parameter. The <code>updateValue</code>
 * method checks if the current <code>country</code> value in the query exists
 * in the list of options. If it exists in the list, nothing needs to be done.
 * However, if the current value does not exist in the list, the query object
 * needs a default value. The <code>ChainedOption</code> then calculates a
 * default value, possibly by calling its
 * {@link net.sf.chainedoptions.ChainedOptionStrategy}, and the <code>country</code>
 * property in the query object is set to the default value.
 * 
 * @see net.sf.chainedoptions.AbstractChainedOption
 * @see net.sf.chainedoptions.ChainedOptionManager
 * @see net.sf.chainedoptions.AbstractChainedOption
 * 
 * @author Mattias Arthursson
 * @author Ulrik Sandberg
 */
public interface ChainedOption {
    /**
     * Retrieve a value List for this ChainedOption corresponding to the current
     * values in the <code>command</code> that this <code>ChainedOption</code>
     * depends on. This method may use a {@link BeanConverter}to translate Java
     * Beans to {@link LabelValueBean}objects and an
     * {@link ChainedOptionStrategy}to perform additional modifications to the
     * option list.
     * 
     * @param command
     *            Command object to use when extracting values that the
     *            <code>ChainedOption</code> depends on.
     * @param context
     *            may contain any context that might be interesting for
     *            retreiving valid options. E.g. a
     *            <code>HttpServletRequest</code> object can be supplied as
     *            context for a Strategy to perform filtering based on user
     *            access.
     * 
     * @return A list of {@link LabelValueBean}objects.
     */
    List retrieveOptions(Object command, Object context);

    /**
     * Check the <code>command</code> if it needs to be updated. The
     * <code>options</code> list may be used for choosing a default value.
     * 
     * @param command
     *            The command object that may be updated.
     * @param options
     *            A list of {@link LabelValueBean}objects to choose from.
     * @param context
     *            may contain any context that might be interesting for
     *            retreiving valid options. E.g. a
     *            <code>HttpServletRequest</code> object can be supplied as
     *            context for a Strategy to perform filtering based on user
     *            access.
     */
    void updateValue(Object command, List options, Object context);

    /**
     * Get the key that identifies the list of options corresponding to this
     * <code>ChainedOption</code>.
     * 
     * @return the key as a String.
     */
    String getOptionsKey();

    /**
     * Get the {@link ChainedOptionStrategy}to use for filtering and sorting
     * values as well as for selecting the default value.
     * 
     * @param command
     *            the command to use for selecting the correct Strategy.
     * 
     * @return the <code>ChainedOptionStrategy</code> to use based on the
     *         current situation. Some implementations may have several
     *         strategies to choose from, and this method is responsible for
     *         choosing the correct one in each situation based on the current
     *         values in the <code>command</code>.
     */
    ChainedOptionStrategy getStrategy(Object command);
}
