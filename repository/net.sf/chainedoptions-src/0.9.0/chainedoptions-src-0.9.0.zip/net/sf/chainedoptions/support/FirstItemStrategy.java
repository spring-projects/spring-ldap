package net.sf.chainedoptions.support;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import net.sf.chainedoptions.ChainedOptionStrategy;
import net.sf.chainedoptions.LabelValueBean;


/**
 * A ChainedOptionStrategy that adds no extra items and returns the first in the
 * option list as default value.
 * 
 * @author Mattias Arthursson
 */
public class FirstItemStrategy implements ChainedOptionStrategy {

    /**
     * Just sort the options for this implementation.
     * 
     * @param options
     *            the options to sort.
     * @param context
     *            ignored for this implementation.
     * 
     * @return a new Sorted list containing the options.
     */
    public List adjustAndSort(List options, Object context) {
        LinkedList result = new LinkedList();
        result.addAll(options);
        Collections.sort(result);
        return result;
    }

    /**
     * Return the value of the first item as default value. If the list is
     * empty, return empty String.
     * 
     * @param options
     *            the list of options.
     * @param context
     *            ignored for this implementation.
     * @return the value of the first item in the List if the List is not empty,
     *         empty String otherwise.
     */
    public String getDefaultValue(List options, Object context) {
        if (options.size() > 0) {
            LabelValueBean bean = (LabelValueBean) options.get(0);
            return bean.getValue();
        } else {
            return "";
        }
    }

}
