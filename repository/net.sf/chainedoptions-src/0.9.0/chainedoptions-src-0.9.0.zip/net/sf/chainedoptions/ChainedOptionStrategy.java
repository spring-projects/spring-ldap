package net.sf.chainedoptions;

import java.util.List;

/**
 * Interface for a strategy that is responsible for sorting and filtering the
 * list of available options and providing a reasonable default value. The
 * strategy may also adjust the list of options, for example by adding an option
 * representing any of the available options, like for example an ANY_REGION
 * option, which comes in handy in some search pages.
 * 
 * @author Mattias Arthursson
 * @author Ulrik Sandberg
 */
public interface ChainedOptionStrategy {
    /**
     * Sorts the given list of options. May also adjust the list of options by
     * adding or removing entries.
     * 
     * @param options
     *            List of LabelValueBean objects to adjust and sort.
     * @param context
     *            may contain any context that might be interesting for the
     *            Strategy for fitering or adding values. E.g. the Request
     *            object might be passed as context for the Strategy in order to
     *            hide some options depending on user access.
     * 
     * @return A sorted list of LabelValueBean objects.
     * @see LabelValueBean
     */
    List adjustAndSort(List options, Object context);

    /**
     * Provides the default value of the given list of options.
     * 
     * @param options
     *            List of LabelValueBean objects where the default value must be
     *            found.
     * @param context
     *            may contain any context that might be interesting for the
     *            Strategy to select the default value.
     * 
     * @return A value representing the default value of the given list of
     *         options.
     */
    String getDefaultValue(List options, Object context);
}
