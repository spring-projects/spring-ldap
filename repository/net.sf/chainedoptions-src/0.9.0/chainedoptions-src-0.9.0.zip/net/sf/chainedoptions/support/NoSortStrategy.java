package net.sf.chainedoptions.support;

import java.util.List;

import net.sf.chainedoptions.ChainedOptionStrategy;
import net.sf.chainedoptions.LabelValueBean;


/**
 * Strategy that does not perform any sorting and returns the first item in the
 * list as default value.
 * 
 * @author Mattias Arthursson
 */
public class NoSortStrategy extends Object implements ChainedOptionStrategy {

    /**
     * Do nothing, just return the supplied list.
     * 
     * @param options
     *            the list to return.
     * @param context
     *            ignored for this implementation.
     * @return the supplied list, unmodified.
     */
    public List adjustAndSort(List options, Object context) {
        return options;
    }

    /**
     * Returns the value of the first item in the list.
     * 
     * @param options
     *            the list of options.
     * @param context
     *            ignored for this implementation.
     * @return the value of the first item in the List if the List is not empty,
     *         empty String otherwise.
     */
    public String getDefaultValue(List options, Object context) {
        if (options.size() > 0) {
            LabelValueBean bean = (LabelValueBean) options.get(0);
            return bean.getValue();
        } else {
            return "";
        }
    }

}
