package net.sf.chainedoptions.support;

import net.sf.chainedoptions.AbstractBeanConverter;
import net.sf.chainedoptions.LabelValueBean;

/**
 * BeanConverter for String objects. Constructs LabelValueBeans with label and
 * value as the supplied String.
 * 
 * @author Mattias Arthursson
 */
public class StringBeanConverter extends AbstractBeanConverter {

    /**
     * Create a <code>LabelValueBean</code> with name and value as the
     * supplied String.
     * 
     * @param object
     *            <code>String</code> to convert.
     * @return a new <code>LabelValueBean</code>
     * @throws ClassCastException
     *             if the supplied <code>object</code> is not a
     *             <code>String</code>.
     */
    protected LabelValueBean convertBean(Object object) {
        String string = (String) object;
        return new LabelValueBean(string, string);
    }
}
