package net.sf.chainedoptions.support;

import java.util.LinkedList;
import java.util.List;

import net.sf.chainedoptions.ChainedOption;
import net.sf.chainedoptions.ChainedOptionStrategy;
import net.sf.chainedoptions.LabelValueBean;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.factory.InitializingBean;


/**
 * Decorator to provide support for optional refresh on the target
 * <code>ChainedOption</code>. The specified <code>refreshProperty</code>
 * property on the target <code>command</code> is inspected prior to
 * forwarding any <code>retrieveOptions</code> and <code>updateValue</code>
 * calls to the target <code>ChainedOption</code>.
 * 
 * If this property is <code>false</code> an empty List will be returned by
 * <code>retrieveOptions</code>, and <code>updateValue</code> will do
 * nothing.
 * <p>
 * Such a behavior is useful for example when a click in a checkbox should
 * change another field between a selectbox (for fixed values) and a textbox
 * (for free text search).
 * 
 * @author Mattias Arthursson
 */
public class OptionalRefreshChainedOption implements ChainedOption,
        InitializingBean {

    private ChainedOption chainedOption;

    private String refreshProperty;

    /**
     * Forward the <code>retrieveOptions</code> call to the target
     * <code>ChainedOption</code> if the <code>refreshProperty</code> property
     * on the target command is true.
     * 
     * @param command
     *            Command object to use when extracting values that the
     *            <code>ChainedOption</code> depends on.
     * @param context
     *            may contain any context that might be interesting for
     *            retreiving valid options. E.g. a
     *            <code>HttpServletRequest</code> object can be supplied as
     *            context for a Strategy to perform filtering based on user
     *            access.
     * 
     * @return the result of retrieveOptions on the target ChainedOption if we are
     *         to forward, an empty <code>LinkedList</code> otherwise.
     * 
     * @see net.sf.chainedoptions.ChainedOption#retrieveOptions(java.lang.Object, java.lang.Object)
     */
    public List retrieveOptions(Object command, Object context) {
        if (getRefreshPropertyAsBoolean(command)) {
            return chainedOption.retrieveOptions(command, context);
        } else {
            return new LinkedList();
        }
    }

    /**
     * Forward the <code>updateValue</code> call to the target
     * <code>ChainedOption</code if the <code>refreshProperty</code> property on the target command is true.
     * @param command
     *            The command object that may be updated.
     * @param options
     *            A list of {@link LabelValueBean}objects to choose from.
     * @param context
     *            may contain any context that might be interesting for
     *            retreiving valid options. E.g. a
     *            <code>HttpServletRequest</code> object can be supplied as
     *            context for a Strategy to perform filtering based on user
     *            access.
     * 
     * @see net.sf.chainedoptions.ChainedOption#updateValue(java.lang.Object, java.util.List, java.lang.Object)
     */
    public void updateValue(Object command, List options, Object context) {
        if (getRefreshPropertyAsBoolean(command)) {
            chainedOption.updateValue(command, options, context);
        }
    }

    private boolean getRefreshPropertyAsBoolean(Object command) {
        BeanWrapper commandWrapper = new BeanWrapperImpl(command);
        Boolean bool = (Boolean) commandWrapper
                .getPropertyValue(refreshProperty);
        return bool.booleanValue();
    }

    /**
     * Forward the call to the target <code>ChainedOption</code>
     * 
     * @return the result from the target ChainedOption.
     */
    public String getOptionsKey() {
        return chainedOption.getOptionsKey();
    }

    /**
     * Set the <code>ChainedOption</code> that this decorator wraps.
     * 
     * @param chainedOption
     *            the <code>ChainedOption</code> to forward calls to.
     */
    public void setChainedOption(ChainedOption chainedOption) {
        this.chainedOption = chainedOption;
    }

    /**
     * Set the name of the property to inspect on the <code>command</code>
     * object to determine whether {@link #retrieveOptions(Object, Object)}and
     * {@link #updateValue(Object, List, Object)}should forward the call to the
     * target <code>ChainedOption</code>.
     * 
     * @param refreshProperty
     *            name of the property.
     */
    public void setRefreshProperty(String refreshProperty) {
        this.refreshProperty = refreshProperty;
    }

    /*
     * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
     */
    public void afterPropertiesSet() throws Exception {
        if (refreshProperty == null) {
            throw new IllegalArgumentException(
                    "Property 'refreshProperty' must be set.");
        }

        if (chainedOption == null) {
            throw new IllegalArgumentException(
                    "Property 'chainedOption' must be set.");
        }
    }

    /**
     * Forward the call to the target <code>ChainedOption</code>.
     * 
     * @param command
     *            the <code>command</code> to operate on.
     * @return the value returned from the target <code>ChainedOption</code>.
     */
    public ChainedOptionStrategy getStrategy(Object command) {
        return chainedOption.getStrategy(command);
    }
}
