package net.sf.chainedoptions;

import java.beans.PropertyEditor;
import java.beans.PropertyEditorManager;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.PropertyValue;
import org.springframework.beans.factory.InitializingBean;

/**
 * Abstract class that implements the ChainedOption interface and provides an
 * implementation of {@link #updateValue(Object, List, Object)}. This
 * implementation loops through the list of options and checks if the
 * <code>commandProperty</code> in the <code>command</code> object matches
 * any item in the list. If it doesn't, a default value is set in the command
 * object. The default value is provided by the <code>ChainedOptionStrategy</code>
 * retrieved from the {@link #getStrategy(Object)}method.
 * <p>
 * Subclasses must implement the method {@link #retrieveOptions(Object, Object)}
 * method. Below is an example of such an implementation:
 * 
 * <pre>
 * package com.acme.valuehandler;
 * 
 * import java.util.List;
 * import com.acme.valuehandler.config.RegionConfig;
 * 
 * public class CountryChainedOption extends AbstractChainedOption {
 * 
 *     private RegionConfig regionConfig;
 * 
 *     private String regionProperty;
 * 
 *     public List retrieveOptions(Object command) {
 *         String region = getProperty(command, regionProperty);
 *         List countryBeans = regionConfig.getCountries(region);
 *         List countries = getConverter().convert(countryBeans);
 *         return getStrategy().adjustAndSort(countries);
 *     }
 * }
 * </pre>
 * 
 * @author Mattias Arthursson
 * @author Ulrik Sandberg
 */
public abstract class AbstractChainedOption implements ChainedOption,
        InitializingBean {

    private String commandProperty;

    private String optionsKey;

    private BeanConverter converter;

    private ChainedOptionStrategy defaultStrategy;

    public abstract List retrieveOptions(Object command, Object context);

    /**
     * Default implementation of <code>updateValue</code>, which loops
     * through the list of available options and compares them to the current
     * value of the managed attribute in the <code>command</code> object.
     * <p />
     * If the selected value is present in the list, no modifications are done
     * in the <code>command</code>, otherwise a default value is retrieved by
     * calling {@link ChainedOptionStrategy#getDefaultValue(List, Object)}, and
     * the <code>commandProperty</code> in the <code>command</code> is set
     * to this value.
     * 
     * @param command
     *            the object which will possibly be updated with a new object.
     * @param options
     *            the list of options with which the managed value in the
     *            <code>command</code> will be compared.
     * @param context
     *            a context that will be supplied to the
     *            <code>ChainedOptionStrategy</code> for selecting an
     *            appropriate default value.
     * @see ChainedOptionStrategy#getDefaultValue(List, Object)
     */
    public void updateValue(Object command, List options, Object context) {
        Object selectedValue = getProperty(command, getCommandProperty());
        if (selectedValue != null) {
            PropertyEditor propertyEditor = PropertyEditorManager
                    .findEditor(selectedValue.getClass());
            String selectedValueAsString;
            if (propertyEditor != null) {
                propertyEditor.setValue(selectedValue);
                selectedValueAsString = propertyEditor.getAsText();
            } else {
                selectedValueAsString = (String) selectedValue;
            }

            for (Iterator iter = options.iterator(); iter.hasNext();) {
                if (matches((LabelValueBean) iter.next(), selectedValueAsString)) {
                    return;
                }
            }
        }

        setProperty(command, getCommandProperty(), getStrategy(command)
                .getDefaultValue(options, context));
    }

    /**
     * Utility method that matches the value of the given <code>bean</code>
     * with the specified <code>value</code>.
     * 
     * @param bean
     *            The {@link LabelValueBean}to match the value against.
     * @param value
     *            The value to match.
     * @return <code>true</code> if the values match.
     */
    protected boolean matches(LabelValueBean bean, String value) {
        return StringUtils.equals(((LabelValueBean) bean).getValue(), value);
    }

    /**
     * Checks if all necessary properties have been set. Subclasses should
     * override {@link #initChainedOption()}if additional integrity checks are
     * needed on initialization.
     * 
     * @throws IllegalArgumentException
     *             if any mandatory property has not been set.
     */
    public final void afterPropertiesSet() throws Exception {
        if (commandProperty == null) {
            throw new IllegalArgumentException(
                    "Property 'commandProperty' must be set");
        }
        if (optionsKey == null) {
            throw new IllegalArgumentException(
                    "Property 'optionsKey' must be set");
        }
        if (defaultStrategy == null) {
            throw new IllegalArgumentException(
                    "Property 'defaultStrategy' must be set");
        }
        initChainedOption();
    }

    /**
     * Template method that subclasses may implement to ensure proper
     * initialization. This method is called after all properties has been set.
     */
    protected void initChainedOption() {
    }

    /**
     * Utility method that sets a named property on a given object.
     * 
     * @param bean
     *            The object to set the property on.
     * @param propertyName
     *            The name of the property to set.
     * @param value
     *            The value that the property will be set to.
     */
    protected void setProperty(Object bean, String propertyName, Object value) {
        BeanWrapper commandWrapper = new BeanWrapperImpl(bean);
        commandWrapper.setPropertyValue(new PropertyValue(propertyName, value));
    }

    /**
     * Utility method that gets a named property from a given object.
     * 
     * @param bean
     *            The object to get the property from.
     * @param property
     *            The name of the property to get.
     * @return The property value.
     */
    protected Object getProperty(Object bean, String property) {
        BeanWrapper commandWrapper = new BeanWrapperImpl(bean);
        return commandWrapper.getPropertyValue(property);
    }

    /**
     * @return Returns the commandProperty.
     */
    public String getCommandProperty() {
        return commandProperty;
    }

    /**
     * Set the property on the target <code>command</code> object managed by
     * this instance.
     * 
     * @param commandProperty
     *            The commandProperty to set.
     */
    public void setCommandProperty(String commandProperty) {
        this.commandProperty = commandProperty;
    }

    /**
     * @return Returns the optionsKey.
     */
    public String getOptionsKey() {
        return optionsKey;
    }

    /**
     * Set the key that should identify the option list managed by this
     * instance.
     * 
     * @param optionsKey
     *            The optionsKey to set.
     */
    public void setOptionsKey(String optionsKey) {
        this.optionsKey = optionsKey;
    }

    /**
     * @return Returns the converter.
     */
    public BeanConverter getConverter() {
        return converter;
    }

    /**
     * Set the <code>BeanConverter</code> that should be used for translating
     * to LabelValueBeans.
     * 
     * @param converter
     *            The converter to set.
     */
    public void setConverter(BeanConverter converter) {
        this.converter = converter;
    }

    /**
     * Override this if the implementation has several strategies.
     * 
     * @return this implementation returns the <code>defaultStrategy</code>.
     */
    public ChainedOptionStrategy getStrategy(Object command) {
        return defaultStrategy;
    }

    /**
     * Set the default strategy to use.
     * 
     * @param defaultStrategy
     *            the default strategy to set.
     */
    public void setDefaultStrategy(ChainedOptionStrategy defaultStrategy) {
        this.defaultStrategy = defaultStrategy;
    }
}
